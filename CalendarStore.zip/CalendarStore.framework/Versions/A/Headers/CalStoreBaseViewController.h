//
//  CalStoreBaseViewController.h
//  CalendarStore
//
//  Created by SchedJoules on 11-04-14.
//  Copyright (c) 2014 SchedJoules. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!
 @abstract Base class for ViewControllers in the CalendarStore framework.
 */
@interface CalStoreBaseViewController : UIViewController


@end
