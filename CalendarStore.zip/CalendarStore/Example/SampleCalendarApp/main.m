//
//  main.m
//  SampleCalendarApp
//
//  Created by SchedJoules on 11-02-14.
//  Copyright (c) 2014 SchedJoules. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SJAppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([SJAppDelegate class]));
	}
}
