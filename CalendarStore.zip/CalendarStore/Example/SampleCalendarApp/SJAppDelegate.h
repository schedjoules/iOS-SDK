//
//  SJAppDelegate.h
//  SampleCalendarApp
//
//  Created by SchedJoules on 11-02-14.
//  Copyright (c) 2014 SchedJoules. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SJAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
