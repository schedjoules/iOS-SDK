//
//  CalStoreBaseApiContentViewController.h
//  CalendarStore
//
//  Created by SchedJoules on 17-02-14.
//  Copyright (c) 2014 SchedJoules. All rights reserved.
//

#import <UIKit/UIKit.h>

/*!
 @abstract Base class for ViewControllers that show API content.
 */
@interface CalStoreBaseApiContentViewController : UIViewController

@end

